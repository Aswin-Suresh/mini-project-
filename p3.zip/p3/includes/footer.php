<footer id="footer">
  <div class="container">
    <div class="copyright">
    	<!-- <h5>© <?php echo date("Y"); ?> Carrental portal</h5> -->
      ©<?php echo date("Y"); ?> <strong>Carrental portal</strong>. All Rights Reserved
    </div>
  </div>
</footer>